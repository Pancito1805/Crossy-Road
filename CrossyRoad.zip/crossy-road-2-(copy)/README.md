# Crossy Road 2 - Godot Game Project

Un clon del juego Crossy Road desarrollado en Godot Engine 4.5 como proyecto educativo.

## 📋 Descripción

Este proyecto recrea la mecánica básica del popular juego Crossy Road, donde el jugador controla una paloma que debe avanzar saltando por casillas. El proyecto incluye:

- Sistema de movimiento discreto tipo grid
- Cámara en tercera persona fija
- Controles WASD y flechas
- Rotación automática del personaje
- Física básica con gravedad

## 🎮 Controles

| Tecla | Acción |
|-------|--------|
| **W** / **↑** | Avanzar hacia adelante |
| **S** / **↓** | Retroceder |
| **A** / **←** | Moverse a la izquierda |
| **D** / **→** | Moverse a la derecha |

## 📁 Estructura del Proyecto

```
crossy-road-2/
├── icon.svg                      # Icono del proyecto
├── project.godot                 # Archivo de configuración de Godot
├── README.md                     # Este archivo
├── Documentacion_Proyecto.md     # Documentación detallada
├── Documentacion_Proyecto.docx   # Documentación en formato Word
├── build/                        # Carpeta para builds exportados
└── src/
    ├── assets/                   # Recursos 3D
    │   ├── EscenarioPrincipal.glb
    │   └── Paloma.glb
    ├── scenes/                   # Escenas del juego
    └── script/                   # Scripts GDScript
        ├── escenario_principal.gd
        └── jugador.gd
```

## 🚀 Cómo Ejecutar el Proyecto

### Requisitos Previos

- [Godot Engine 4.5](https://godotengine.org/download) o superior
- Sistema operativo: Windows, Linux o macOS

### Pasos de Instalación

1. **Clonar o descargar el repositorio:**
   ```bash
   git clone https://github.com/tu-usuario/crossy-road-2.git
   cd crossy-road-2
   ```

2. **Abrir el proyecto en Godot:**
   - Abre Godot Engine
   - Haz clic en "Import"
   - Navega hasta la carpeta del proyecto
   - Selecciona el archivo `project.godot`
   - Haz clic en "Import & Edit"

3. **Ejecutar el juego:**
   - Presiona **F5** o el botón de "Play" en la esquina superior derecha
   - O selecciona una escena y presiona **F6** para ejecutar esa escena específica

## 🎨 Configuración de Escenas

### Escena del Jugador (Paloma)

La escena del jugador debe tener la siguiente jerarquía de nodos:

```
Jugador (CharacterBody3D)
├── Paloma.glb (modelo 3D)
├── CollisionShape3D
└── PivoteCamara (Node3D) [Top Level: ✓]
    └── Camera3D
```

**Importante:** Asegúrate de activar la propiedad `Top Level` en el nodo `PivoteCamara` para que la cámara no herede las rotaciones del personaje.

### Escena del Escenario

```
EscenarioPrincipal (Node3D)
└── EscenarioPrincipal.glb (modelo 3D)
```

## ⚙️ Scripts Principales

### `jugador.gd`

Maneja toda la lógica del personaje:
- Movimiento discreto por saltos
- Sistema de cámara en tercera persona
- Rotación automática según dirección
- Física y gravedad

**Variables configurables:**
- `distancia_salto`: 2.0 - Distancia de cada salto
- `duracion_salto`: 0.3 - Duración del salto en segundos
- `altura_salto`: 1.0 - Altura del arco del salto
- `distancia_camara`: 10.0 - Distancia de la cámara
- `altura_camara`: 8.0 - Altura de la cámara

### `escenario_principal.gd`

Maneja la lógica del mundo del juego:
- Límites del escenario
- Base para generación de obstáculos (extensible)

**Variables configurables:**
- `ancho_escenario`: 50.0
- `largo_escenario`: 100.0

## 🔧 Características Técnicas

### Sistema de Movimiento
- **Tipo:** Discreto/Grid-based
- **Mecánica:** Salto con arco parabólico
- **Control:** Un salto por pulsación de tecla
- **Rotación:** Instantánea hacia la dirección del movimiento

### Sistema de Cámara
- **Tipo:** Tercera persona fija
- **Comportamiento:** Sigue al jugador sin rotar
- **Implementación:** Nodo con `top_level` activado

### Física
- **CharacterBody3D** para el jugador
- **Gravedad** aplicada cuando no está en el suelo
- **Detección de colisiones** con el escenario
