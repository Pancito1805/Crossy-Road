extends CharacterBody3D

# Script para el jugador (Paloma) estilo Crossy Road

# Variables de movimiento
@export var distancia_salto: float = 2.0
@export var duracion_salto: float = 0.3
@export var altura_salto: float = 1.0

# Variables de cámara
@export var distancia_camara: float = 10.0
@export var altura_camara: float = 8.0
@export var offset_camara_adelante: float = 5.0  # Para que la cámara vea al frente

# Control de movimiento
var esta_moviendo: bool = false
var posicion_objetivo: Vector3
var posicion_inicial: Vector3
var tiempo_movimiento: float = 0.0

# Referencias a los nodos de cámara
@onready var pivote_camara: Node3D = $PivoteCamara
@onready var camara: Camera3D = $PivoteCamara/Camera3D

func _ready() -> void:
	print("Jugador inicializado")
	configurar_camara()

func configurar_camara() -> void:
	# Configurar la cámara para que esté detrás y arriba del jugador
	if camara and pivote_camara:
		# El pivote NO rota, permanece completamente fijo
		pivote_camara.position = Vector3.ZERO
		pivote_camara.top_level = true  # Hacer que el pivote no herede transformaciones
		# Posicionar la cámara DETRÁS del jugador mirando hacia adelante (eje -Z)
		camara.position = Vector3(0, altura_camara, -distancia_camara)
		# La cámara mira hacia adelante en el eje -Z
		camara.rotation_degrees = Vector3(-30, 180, 0)  # Ángulo fijo hacia abajo

func _physics_process(delta: float) -> void:
	manejar_movimiento(delta)
	actualizar_camara()  # Actualizar posición de cámara
	if esta_moviendo:
		actualizar_salto(delta)
	aplicar_gravedad(delta)

func actualizar_camara() -> void:
	# La cámara sigue al jugador pero NO rota
	if pivote_camara:
		pivote_camara.global_position = global_position

func manejar_movimiento(delta: float) -> void:
	if esta_moviendo:
		return
	
	var direccion := Vector3.ZERO
	
	# Movimiento tipo Crossy Road: salto por tecla
	if Input.is_action_just_pressed("ui_up") or Input.is_key_pressed(KEY_W):
		direccion = Vector3(0, 0, 1)  # Adelante
	elif Input.is_action_just_pressed("ui_down") or Input.is_key_pressed(KEY_S):
		direccion = Vector3(0, 0, -1)   # Atrás
	elif Input.is_action_just_pressed("ui_left") or Input.is_key_pressed(KEY_A):
		direccion = Vector3(1, 0, 0)  # Izquierda
	elif Input.is_action_just_pressed("ui_right") or Input.is_key_pressed(KEY_D):
		direccion = Vector3(-1, 0, 0)   # Derecha
	
	if direccion != Vector3.ZERO:
		iniciar_salto(direccion)

func iniciar_salto(direccion: Vector3) -> void:
	esta_moviendo = true
	tiempo_movimiento = 0.0
	posicion_inicial = global_position
	posicion_objetivo = global_position + direccion * distancia_salto
	
	# Rotar la paloma según la dirección del movimiento
	if direccion == Vector3(0, 0, -1):   # Adelante (W)
		rotation.y = 0
	elif direccion == Vector3(0, 0, 1):  # Atrás (S)
		rotation.y = PI
	elif direccion == Vector3(-1, 0, 0): # Izquierda (A)
		rotation.y = PI / 2
	elif direccion == Vector3(1, 0, 0):  # Derecha (D)
		rotation.y = -PI / 2

func actualizar_salto(delta: float) -> void:
	tiempo_movimiento += delta
	var progreso = min(tiempo_movimiento / duracion_salto, 1.0)
	
	# Interpolación horizontal
	var nueva_pos = posicion_inicial.lerp(posicion_objetivo, progreso)
	
	# Arco parabólico para el salto (efecto de altura)
	var altura = altura_salto * sin(progreso * PI)
	nueva_pos.y = posicion_inicial.y + altura
	
	global_position = nueva_pos
	
	# Terminar el salto
	if progreso >= 1.0:
		esta_moviendo = false
		global_position = posicion_objetivo

func aplicar_gravedad(delta: float) -> void:
	# Aplicar gravedad cuando no está saltando
	if not esta_moviendo and not is_on_floor():
		velocity.y -= 9.8 * delta
		move_and_slide()

func _input(event: InputEvent) -> void:
	# Input manejado en manejar_movimiento
	pass
