extends Node3D

# Script para el escenario principal del juego tipo Crossy Road

# Variables configurables
@export var ancho_escenario: float = 50.0
@export var largo_escenario: float = 100.0

func _ready() -> void:
	# Inicializar el escenario
	print("Escenario Principal cargado")
	configurar_escenario()

func configurar_escenario() -> void:
	pass

func _process(delta: float) -> void:
	# Lógica que se ejecuta cada frame
	pass

# Función para verificar si una posición está dentro de los límites del escenario
func esta_dentro_limites(posicion: Vector3) -> bool:
	return abs(posicion.x) <= ancho_escenario / 2.0 and abs(posicion.z) <= largo_escenario / 2.0
